def main():
    print('Hello from Cheese!')
