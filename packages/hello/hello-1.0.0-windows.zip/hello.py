print('Hello from Cheese!')
